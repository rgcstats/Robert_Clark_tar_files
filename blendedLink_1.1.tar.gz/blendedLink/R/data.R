#' An example data file.
#'
#' A dataset with 500 rows containing the values of y (a binary dependent variable equal to 0 or 1),
#' and two covariates x1 and x2 (with continuous values ranging from -1 to 1).
"loglogit.example"
